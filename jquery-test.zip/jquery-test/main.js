"use strict";

$(function() {

    var $formPrincipal = $("form#principal");
    var $formSecundario = $("form#secundario");
    var $corSelecionada = $formPrincipal.find('[name="cor"]');

    var mudarBgColorCallback = function() {

        console.log($formPrincipal.find('[name="cor"]'));

        // Obter valor do radio que está "checked"
        var codigoCorSelecionada = $formPrincipal.find('[name="cor"]:checked').val();

        // Setar "background-color" no form principal
        $formPrincipal.css("background-color", codigoCorSelecionada);
    };

    // Bind dinâmico
    $formPrincipal.on("change", '[name="cor"]', mudarBgColorCallback);

    /* $("#alterarBgColor").on("click", mudarBgColorCallback); */
    
    var $btnAddCor = $formSecundario.find(".btn-add-cor");

    $btnAddCor.on("click", function() {

        var codigo = "black";
        var nome = "Preto";
        
        var html = `
        <div class="form-check">
            <input class="form-check-input" type="radio" name="cor" id="cor-${codigo}" value="${codigo}">
            <label class="form-check-label" for="cor-${codigo}">${nome}</label>
        </div>`;

        $formPrincipal.find(".form-group-cor").append(html);

    });

});